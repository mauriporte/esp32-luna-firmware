#pragma once
// GifPlayer — ESP32-S3-BOX-3B Luna firmware GIF player.
//
// Mounts a USB mass-storage SD card (plugged into the BOX-3-DOCK USB-A host port)
// over the ESP-IDF USB host + MSC stack, then decodes GIFs from the mounted VFS
// path (/sd/<name>.gif) with the vendored lecram/gifdec decoder and renders each
// frame to the display as RGB565 via Display::draw_pixels_at().
//
// The decoder reads via POSIX open/read/lseek, which the MSC VFS mount supports
// directly — no decoder refactor is needed. The indexed+RGB canvas (~300 KB at
// 320x240) and the RGB24/RGB565 staging buffers are allocated in PSRAM.

#include "esphome.h"
#include "gifdec.h"
#include "usb/msc_host.h"
#include "usb/msc_host_vfs.h"

#include "esphome/components/runtime_image/runtime_image.h"

namespace esphome {
namespace gif_player {

class GifPlayer : public Component {
 public:
  void setup() override;
  void loop() override;  // mounts / unmounts the USB drive on the main task (hot-plug safe)

  // Open /sd/<name>.gif, decode the first frame, begin playback.
  // Returns true on success.
  bool load(const std::string &name);

  // Stop playback and release all GIF buffers.
  void stop();

  // Advance to the next frame if the frame delay has elapsed; re-renders the
  // RGB565 staging buffer. Called from the display page lambda.
  void tick();

  // Blit the current RGB565 frame to the display. Called from the display page
  // lambda after tick(). No-op when no GIF is active.
  template <typename T>
  void draw(T &it) {
    if (still_active_ && still_ != nullptr) {  // pictures keep their shape: centred on black
      it.fill(Color::BLACK);
      still_->draw((it.get_width() - still_->get_width()) / 2, (it.get_height() - still_->get_height()) / 2, &it,
                   Color::WHITE, Color::BLACK);
      return;
    }
    if (!active_ || !gif_ || !rgb565_) return;
    it.draw_pixels_at(0, 0, width_, height_, rgb565_,
                      display::ColorBitness::COLOR_BITNESS_565, true);  // big-endian frames
  }

  bool is_active() const { return active_ || still_active_; }
  bool is_mounted() const { return mounted_; }

 private:
  static void usb_host_task(void *arg);
  static void msc_event_cb(const msc_host_event_t *event, void *arg);

  void alloc_buffers();
  bool load_still_(const char *path, runtime_image::ImageFormat fmt);
  void free_buffers();

  gd_GIF *gif_ = nullptr;
  uint8_t *rgb24_ = nullptr;   // width_ * height_ * 3  (gd_render_frame output)
  uint8_t *rgb565_ = nullptr;  // width_ * height_ * 2  (display blit source)
  bool active_ = false;
  bool mounted_ = false;
  volatile bool host_ok_ = false;  // USB host + MSC driver installed
  runtime_image::RuntimeImage *still_ = nullptr;  // decoded .jpg/.png, fitted inside 320x240 keeping its shape
  bool still_active_ = false;
  volatile uint8_t pending_addr_ = 0;        // set by the USB task: a drive was plugged in
  volatile bool pending_disconnect_ = false;  // set by the USB task: the drive was pulled out
  int width_ = 0, height_ = 0;
  uint32_t next_frame_ms_ = 0;

  // USB host MSC state
  msc_host_device_handle_t msc_dev_ = nullptr;
  msc_host_vfs_handle_t vfs_handle_ = nullptr;
};

// Single instance shared with the static MSC callback (set in setup()).
extern GifPlayer *s_gif_player;

}  // namespace gif_player
}  // namespace esphome
