#pragma once
// Screen modes backed by folders on the SD card (Mau 28/11). Each mode plays the .gif files of its folder;
// the file list is read from the card whenever a mode starts, so new files only need copying to the card.
#include "esphome.h"
#include <dirent.h>
#include <cerrno>
#include <algorithm>
#include <cctype>
#include <cstring>
#include <string>
#include <vector>

namespace media {

inline std::string squash_(std::string n) {  // lower case, no trailing 's': "Memes" == "meme", "GIFs" == "gif"
  for (auto &c : n) c = (char) tolower((unsigned char) c);
  if (n.size() > 1 && n.back() == 's') n.pop_back();
  return n;
}

// mode name (HA select) -> the matching folder on the USB drive ("" = Faces, the normal eyes/buttons).
// Matched loosely so "Logo"/"logos"/"LOGOS" or "Meme"/"Memes" all work.
inline std::string folder_for(const std::string &mode) {
  if (mode == "Faces") return "";
  std::string want = squash_(mode), found;
  DIR *d = opendir("/sd");
  if (d == nullptr) return mode;
  while (struct dirent *e = readdir(d))
    if (e->d_type == DT_DIR && squash_(e->d_name) == want) { found = e->d_name; break; }
  closedir(d);
  return found.empty() ? mode : found;
}

// the .gif/.jpg/.jpeg/.png files in /sd/<folder>, names without extension, sorted
inline std::vector<std::string> list(const std::string &folder) {
  std::vector<std::string> out;
  DIR *d = opendir(("/sd/" + folder).c_str());
  if (d == nullptr) return out;
  while (struct dirent *e = readdir(d)) {
    std::string n = e->d_name;
    if (n.size() <= 4 || n[0] == '.') continue;
    std::string low = n;
    for (auto &c : low) c = (char) tolower((unsigned char) c);
    auto ends = [&](const char *e) { size_t k = strlen(e); return low.size() > k && low.compare(low.size() - k, k, e) == 0; };
    if (ends(".gif") || ends(".jpg") || ends(".jpeg") || ends(".png")) out.push_back(n);  // keeps the extension
  }
  closedir(d);
  std::sort(out.begin(), out.end());
  return out;
}

// log what the BOX sees in a folder of the drive ("" = top level), for checking the card
inline void dump(const std::string &folder) {
  std::string path = "/sd" + (folder.empty() ? std::string() : "/" + folder);
  DIR *d = opendir(path.c_str());
  if (d == nullptr) { ESP_LOGW("media", "cannot open %s (errno %d)", path.c_str(), errno); return; }
  int n = 0;
  while (struct dirent *e = readdir(d)) {
    if (n++ < 40) ESP_LOGI("media", "  %s%s", e->d_name, e->d_type == DT_DIR ? "/" : "");
  }
  closedir(d);
  ESP_LOGI("media", "%s: %d entries", path.c_str(), n);
}

inline int index_of(const std::vector<std::string> &v, const std::string &name) {
  for (size_t i = 0; i < v.size(); i++)
    if (v[i] == name) return (int) i;
  return -1;
}

}  // namespace media
