"""GIF player component for the ESP32-S3-BOX-3B Luna firmware.

Mounts a USB mass-storage SD card (BOX-3-DOCK USB-A host port) over the
ESP-IDF USB host + MSC stack, then decodes GIFs from the mounted VFS path
(/sd/<name>.gif) with the vendored lecram/gifdec decoder and renders each
frame to the display as RGB565.

The component owns the USB host task and exposes a C++ GifPlayer object that
the YAML display page lambda calls:
  id(gif_player).tick()     — advance to the next frame when its delay elapses
  id(gif_player).draw(it)   — blit the current RGB565 frame to the display
  id(gif_player).load(name) — open /sd/<name>.gif and begin playback
  id(gif_player).stop()     — stop playback and release buffers
"""

import logging

import esphome.codegen as cg
import esphome.config_validation as cv
from esphome.components.esp32 import (
    add_idf_component,
    include_builtin_idf_component,
    idf_version,
)
from esphome.const import CONF_ID
from esphome.core import CORE

_LOGGER = logging.getLogger(__name__)

DOMAIN = "gif_player"
AUTO_LOAD = ["runtime_image"]  # ESPHome's JPEG/PNG decoders for still pictures (Mau 28/11)
DEPENDENCIES = ["esp32"]

gif_player_ns = cg.esphome_ns.namespace("gif_player")
GifPlayer = gif_player_ns.class_("GifPlayer", cg.Component)

CONFIG_SCHEMA = cv.COMPONENT_SCHEMA.extend(
    {
        cv.GenerateID(): cv.declare_id(GifPlayer),
    }
)


async def to_code(config):
    var = cg.new_Pvariable(config[CONF_ID])
    await cg.register_component(var, config)
    from esphome.components.runtime_image import enable_format
    enable_format("JPEG")
    enable_format("PNG")

    if not CORE.using_arduino:  # ESPHome 2026.11 dropped CORE.using_esp_idf
        # IDF 6.0 moved the USB host stack out of the built-in components into
        # the ESP Component Registry; IDF 5.x ships it built-in.
        if idf_version() >= cv.Version(6, 0, 0):
            add_idf_component(name="espressif/usb", ref="1.6.1")
        # usb_host_msc provides the MSC class driver + VFS mount helper.
        # usb_host_msc is a registry component on IDF 5.x too (ESPHome 2026.11 builds with IDF 5.5.6)
        add_idf_component(name="espressif/usb_host_msc", ref="1.3.0")

        # The VFS FAT mount (msc_host_vfs_register) needs FatFS + wear levelling,
        # both of which ESPHome 2026.x excludes by default.
        include_builtin_idf_component("fatfs")
        include_builtin_idf_component("wear_levelling")
