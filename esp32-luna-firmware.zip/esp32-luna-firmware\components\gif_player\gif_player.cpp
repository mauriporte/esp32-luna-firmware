// GifPlayer implementation — ESP32-S3-BOX-3B Luna firmware GIF player.
//
// Mounts a USB mass-storage SD card (BOX-3-DOCK USB-A host port) over the
// ESP-IDF USB host + MSC stack, then decodes GIFs from /sd/<name>.gif with the
// vendored lecram/gifdec decoder and renders frames as RGB565 via
// Display::draw_pixels_at().

#pragma GCC optimize("O2")
#include "gif_player.h"

#include <cstdio>
#include <unistd.h>
#include <fcntl.h>
#include <cerrno>
#include <cstring>
#include <vector>
#include <cctype>

#include "esp_log.h"
#include "esp_heap_caps.h"
#include "esp_vfs_fat.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "usb/usb_host.h"
#include "usb/msc_host.h"
#include "usb/msc_host_vfs.h"

namespace esphome {
namespace gif_player {

static const char *TAG = "gif_player";
GifPlayer *s_gif_player = nullptr;

// ---------------------------------------------------------------------------
// USB host MSC
// ---------------------------------------------------------------------------

void GifPlayer::msc_event_cb(const msc_host_event_t *event, void * /*arg*/) {
  // Runs on the USB driver's task: only flag the event; loop() does the work on the
  // main task, so a GIF being decoded/drawn is never freed under its feet.
  auto *self = s_gif_player;
  if (self == nullptr) return;
  if (event->event == msc_host_event_t::MSC_DEVICE_CONNECTED) self->pending_addr_ = event->device.address;
  else if (event->event == msc_host_event_t::MSC_DEVICE_DISCONNECTED) self->pending_disconnect_ = true;
}

void GifPlayer::loop() {
  static uint32_t last_status = 0;
  if (millis() - last_status > 10000) {  // status for the log: is a drive there?
    last_status = millis();
    uint8_t addrs[8];
    int n_dev = 0;
    if (host_ok_) usb_host_device_addr_list_fill(sizeof(addrs), addrs, &n_dev);
    ESP_LOGI(TAG, "USB host %s, %d USB device(s) on the port, drive %s", host_ok_ ? "running" : "NOT running", n_dev,
             mounted_ ? "mounted at /sd" : "not mounted");
  }
  if (pending_disconnect_) {
    pending_disconnect_ = false;
    ESP_LOGW(TAG, "USB drive removed");
    stop();
    if (vfs_handle_ != nullptr) { msc_host_vfs_unregister(vfs_handle_); vfs_handle_ = nullptr; }
    if (msc_dev_ != nullptr) { msc_host_uninstall_device(msc_dev_); msc_dev_ = nullptr; }
    mounted_ = false;
  }
  if (pending_addr_ != 0 && msc_dev_ == nullptr) {
    uint8_t addr = pending_addr_;
    pending_addr_ = 0;
    ESP_LOGI(TAG, "USB drive connected (SD reader or stick)");
    esp_err_t err = msc_host_install_device(addr, &msc_dev_);
    if (err != ESP_OK) { ESP_LOGE(TAG, "drive not usable: %s", esp_err_to_name(err)); msc_dev_ = nullptr; return; }
    const esp_vfs_fat_mount_config_t mount_config = {
        .format_if_mount_failed = false,  // never wipe Mau's drive
        .max_files = 3,
        .allocation_unit_size = 8192,
    };
    err = msc_host_vfs_register(msc_dev_, "/sd", &mount_config, &vfs_handle_);
    if (err != ESP_OK) {
      ESP_LOGE(TAG, "mount failed (%s): the drive must be FAT32 (exFAT/NTFS not supported)", esp_err_to_name(err));
      msc_host_uninstall_device(msc_dev_); msc_dev_ = nullptr; vfs_handle_ = nullptr;
      return;
    }
    mounted_ = true;
    ESP_LOGI(TAG, "USB drive mounted at /sd");
  }
}

void GifPlayer::usb_host_task(void *arg) {
  auto *self = static_cast<GifPlayer *>(arg);

  const usb_host_config_t host_config = {.intr_flags = ESP_INTR_FLAG_LOWMED};
  ESP_ERROR_CHECK(usb_host_install(&host_config));

  const msc_host_driver_config_t msc_config = {
      .create_backround_task = true,
      .task_priority = 5,
      .stack_size = 4096,
      .callback = GifPlayer::msc_event_cb,
  };
  ESP_ERROR_CHECK(msc_host_install(&msc_config));
  self->host_ok_ = true;

  // Run forever; the MSC driver's own background task services device events.
  while (true) {
    uint32_t event_flags = 0;
    usb_host_lib_handle_events(portMAX_DELAY, &event_flags);
    // Keep the host library alive; never uninstall while the device is attached.
    if (event_flags & USB_HOST_LIB_EVENT_FLAGS_NO_CLIENTS) {
      usb_host_device_free_all();
    }
  }
  // Unreachable in normal operation.
  vTaskDelay(pdMS_TO_TICKS(10));
  usb_host_uninstall();
  vTaskDelete(NULL);
}

// ---------------------------------------------------------------------------
// Component lifecycle
// ---------------------------------------------------------------------------

void GifPlayer::setup() {
  s_gif_player = this;
  // The USB host stack takes over GPIO19/20 (the shared PHY). The main USB-C
  // port's serial function pauses while this task runs — updates go via OTA.
  BaseType_t created = xTaskCreate(GifPlayer::usb_host_task, "gif_usb", 4096, this, 5, nullptr);
  if (created != pdPASS) {
    ESP_LOGE(TAG, "failed to create USB host task");
  }
}

// ---------------------------------------------------------------------------
// GIF buffers
// ---------------------------------------------------------------------------

void GifPlayer::alloc_buffers() {
  const size_t rgb24_sz = static_cast<size_t>(width_) * height_ * 3;
  const size_t rgb565_sz = static_cast<size_t>(width_) * height_ * 2;
  rgb24_ = static_cast<uint8_t *>(heap_caps_calloc(rgb24_sz, 1, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
  rgb565_ = static_cast<uint8_t *>(heap_caps_calloc(rgb565_sz, 1, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
}

void GifPlayer::free_buffers() {
  if (rgb24_ != nullptr) {
    heap_caps_free(rgb24_);
    rgb24_ = nullptr;
  }
  if (rgb565_ != nullptr) {
    heap_caps_free(rgb565_);
    rgb565_ = nullptr;
  }
}

// ---------------------------------------------------------------------------
// GIF playback
// ---------------------------------------------------------------------------

bool GifPlayer::load(const std::string &name) {
  {
    std::string low = name;
    for (auto &ch : low) ch = (char) tolower((unsigned char) ch);
    auto ends = [&](const char *e) { size_t n = strlen(e); return low.size() >= n && low.compare(low.size() - n, n, e) == 0; };
    bool png = ends(".png");
    if (png || ends(".jpg") || ends(".jpeg")) {
      stop();
      if (!mounted_) { ESP_LOGW(TAG, "USB drive not mounted; cannot load %s", name.c_str()); return false; }
      char spath[160];
      snprintf(spath, sizeof(spath), "/sd/%s", name.c_str());
      uint32_t t0 = millis();
      still_active_ = load_still_(spath, png ? runtime_image::PNG : runtime_image::JPEG);
      if (still_active_) ESP_LOGI(TAG, "showing %s (%u ms)", name.c_str(), (unsigned) (millis() - t0));
      else ESP_LOGE(TAG, "could not decode %s", spath);
      return still_active_;
    }
  }

  stop();
  if (!mounted_) {
    ESP_LOGW(TAG, "SD not mounted; cannot load %s", name.c_str());
    return false;
  }

  char path[128];
  // name = "<folder>/<file>" with its extension; a name without one is a .gif (Mau 28/11)
  snprintf(path, sizeof(path), name.find('.') == std::string::npos ? "/sd/%s.gif" : "/sd/%s", name.c_str());
  ESP_LOGI(TAG, "loading %s", path);

  gif_ = gd_open_gif(path);
  if (gif_ == nullptr) {
    int e1 = errno;
    int fd = open(path, O_RDONLY);
    int e2 = errno;
    if (fd >= 0) close(fd);
    FILE *t = fopen(path, "rb");
    ESP_LOGE(TAG, "gd_open_gif(%s) failed (errno %d); open() %s (errno %d); fopen %s", path, e1,
             fd >= 0 ? "works" : "fails", e2, t ? "works" : "fails");
    if (t) fclose(t);
    return false;
  }

  width_ = gif_->width;
  height_ = gif_->height;
  alloc_buffers();
  if (rgb24_ == nullptr || rgb565_ == nullptr) {
    ESP_LOGE(TAG, "out of PSRAM for %dx%d GIF buffers", width_, height_);
    gd_close_gif(gif_);
    gif_ = nullptr;
    return false;
  }

  // Read the first frame and render it immediately.
  if (gd_get_frame(gif_) != 1) {
    ESP_LOGE(TAG, "no frames in %s", path);
    gd_close_gif(gif_);
    gif_ = nullptr;
    free_buffers();
    return false;
  }
  gd_render_frame(gif_, rgb24_);

  // Convert RGB24 -> RGB565 (big-endian, as the S3BOX screen buffer is).
  const size_t pixels = static_cast<size_t>(width_) * height_;
  for (size_t i = 0; i < pixels; i++) {
    uint8_t r = rgb24_[i * 3 + 0];
    uint8_t g = rgb24_[i * 3 + 1];
    uint8_t b = rgb24_[i * 3 + 2];
    uint16_t c = static_cast<uint16_t>((r & 0xF8) << 8 | (g & 0xFC) << 3 | (b >> 3));
    rgb565_[i * 2 + 0] = static_cast<uint8_t>(c >> 8);  // big-endian, the screen's own order: fast memcpy path
    rgb565_[i * 2 + 1] = static_cast<uint8_t>(c & 0xFF);
  }

  active_ = true;
  next_frame_ms_ = millis() + gif_->gce.delay * 10;  // delay is in 1/100 s
  ESP_LOGI(TAG, "playing %s (%dx%d, %d cs/frame)", name.c_str(), width_, height_,
           gif_->gce.delay);
  return true;
}

namespace {
// Lets the JPEG decoder read straight from the file instead of a copy of it in RAM.
struct FileSource : runtime_image::DecodeSource {
  FILE *f;
  explicit FileSource(FILE *file) : f(file) {}
  int32_t read(uint8_t *buf, uint32_t len) override { return (int32_t) fread(buf, 1, len, f); }
  bool seek(uint32_t position) override { return fseek(f, position, SEEK_SET) == 0; }
};
}  // namespace

bool GifPlayer::load_still_(const char *path, runtime_image::ImageFormat fmt) {
  if (still_ == nullptr)
    still_ = new runtime_image::RuntimeImage(fmt, image::IMAGE_TYPE_RGB565, image::TRANSPARENCY_OPAQUE, nullptr,
                                             true /* screen byte order */, 320, 240);
  FILE *f = fopen(path, "rb");
  if (f == nullptr) return false;
  fseek(f, 0, SEEK_END);
  long size = ftell(f);
  fseek(f, 0, SEEK_SET);
  bool ok = false;
  if (size > 0 && still_->begin_decode((size_t) size, fmt)) {
    if (still_->decoder_supports_source()) {
      FileSource src(f);
      if (still_->begin_source(&src) == 0) {
        int r;
        do { r = still_->decode_step(); } while (r == runtime_image::DECODE_STEP_MORE);
        ok = r == runtime_image::DECODE_STEP_DONE;
      }
    } else {
      std::vector<uint8_t> buf(16384);
      size_t have = 0;
      while (true) {
        size_t n = fread(buf.data() + have, 1, buf.size() - have, f);
        have += n;
        if (have == 0) { ok = true; break; }
        int used = still_->feed_data(buf.data(), have);
        if (used < 0) break;
        if (used == 0 && (n == 0 || have == buf.size())) {  // no progress possible
          ok = n == 0 && (still_->is_decode_finished() || !still_->decoder_knows_end());
          break;
        }
        memmove(buf.data(), buf.data() + used, have - used);
        have -= used;
      }
    }
    still_->end_decode();
  }
  fclose(f);
  return ok;
}

void GifPlayer::stop() {
  still_active_ = false;
  if (gif_ != nullptr) {
    gd_close_gif(gif_);
    gif_ = nullptr;
  }
  free_buffers();
  active_ = false;
}

void GifPlayer::tick() {
  if (!active_ || gif_ == nullptr || rgb24_ == nullptr || rgb565_ == nullptr) return;
  if (millis() < next_frame_ms_) return;

  const uint32_t t0 = micros();
  int r = gd_get_frame(gif_);
  if (r == 0) {
    // End of animation: loop back to the start.
    gd_rewind(gif_);
    r = gd_get_frame(gif_);
    if (r != 1) {
      stop();
      return;
    }
  } else if (r != 1) {
    ESP_LOGW(TAG, "gd_get_frame error; stopping");
    stop();
    return;
  }

  const uint32_t t1 = micros();
  gd_render_frame_565be(gif_, reinterpret_cast<uint16_t *>(rgb565_));
  const uint32_t t2 = micros();
  static uint32_t n_frames = 0, sum_dec = 0, sum_ren = 0, sum_cvt = 0;
  const uint32_t t3 = micros();
  sum_dec += t1 - t0; sum_ren += t2 - t1; sum_cvt += t3 - t2;
  if (++n_frames == 50) {  // timing check (Mau 28/11): where a GIF frame's time goes
    ESP_LOGI(TAG, "per frame: decode %u us, render+convert %u us, (unused) %u us", (unsigned) (sum_dec / 50),
             (unsigned) (sum_ren / 50), (unsigned) (sum_cvt / 50));
    n_frames = sum_dec = sum_ren = sum_cvt = 0;
  }
  // keep the GIF's own pace: count the delay from when this frame was due, not from when decoding ended
  const uint32_t now = millis();
  next_frame_ms_ += gif_->gce.delay * 10;
  if ((int32_t) (now - next_frame_ms_) > 0) next_frame_ms_ = now;  // fell behind: don't try to catch up
}

}  // namespace gif_player
}  // namespace esphome
