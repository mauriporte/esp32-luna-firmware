# ESP32 (Luna) firmware — ESP32-S3-BOX-3B

Build: ESPHome 2026.11.0, config `luna_box.yaml` (includes `box_face.h`, `box_pop.h` stub, `wakewords/`).

## Flash over Wi-Fi (BOX already running this firmware)
    esphome upload luna_box.yaml --device 192.168.0.235
or upload `firmware.ota.bin` from the ESPHome dashboard. After an OTA update wait 60 s before pressing Reset
(otherwise the bootloader rolls back to the previous firmware).

## Flash over USB (fresh or recovery)
Use a data USB-C cable (the bundled one is power-only). Hold BOOT, tap RESET, release BOOT, then:
    esptool.py --chip esp32s3 write_flash 0x0 firmware.factory.bin
or https://web.esphome.io → Connect → Install → `firmware.factory.bin`.

## Notes
- Wake words: «Luna» (slot 1, Spanish pipeline) and «Hey Luna v3» (slot 2, English pipeline).
- Touch: GT911, polled every 50 ms, started after the display (setup_priority -100).
- HA must allow the device to perform Home Assistant actions (ESPHome integration option) for the button tiles.
