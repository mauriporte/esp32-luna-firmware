#pragma once
// Pop mode removed (Mau 27/11): no character heads in the firmware. Kept as an empty stub so box_face.h still builds.
#include "esphome.h"
namespace pop {
enum Head { COUNT = 1 };
template <typename T> void draw(T &, int, float, float, float, int, uint32_t) {}
}  // namespace pop
