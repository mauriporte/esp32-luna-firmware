#pragma once

#include "esphome.h"
#include <cmath>
#include <algorithm>
#include "box_pop.h"

enum BoxMood {
    MOOD_NEUTRAL = 0,
    MOOD_HAPPY,
    MOOD_CURIOUS,
    MOOD_FOCUSED,
    MOOD_SLEEPY,
    MOOD_COUNT
};

struct FaceMoodParams {
    float leftSlant;
    float rightSlant;
    float browLeftY;
    float browRightY;
    float browLeftAngle;
    float browRightAngle;
    float eyeScaleY;
    float squint;
    float mouthW;      // half width of the mouth (px)
    float mouthCurve;  // smile depth at the centre (px, + = smile)
    float mouthOpen;   // how open the mouth is (px)
};

static const FaceMoodParams FACE_MOODS[MOOD_COUNT] = {
    // NEUTRAL: soft smile
    { 0.0f,  0.0f, -22.0f, -22.0f,  0.0f,   0.0f,  1.00f, 0.0f,  14.0f, 5.0f, 0.0f },
    // HAPPY: open smile
    { 0.3f, -0.3f, -28.0f, -28.0f,  0.12f, -0.12f, 0.72f, 0.75f, 18.0f, 6.0f, 9.0f },
    // CURIOUS: little "o"
    {-0.22f,-0.22f,-32.0f, -16.0f, -0.22f,  0.10f, 1.08f, 0.0f,   6.0f, 0.0f, 8.0f },
    // FOCUSED: flat line
    { 0.16f,-0.16f,-14.0f, -14.0f,  0.22f, -0.22f, 0.82f, 0.35f, 10.0f, 0.0f, 0.0f },
    // SLEEPY: small yawn
    { 0.0f,  0.0f, -10.0f, -10.0f,  0.0f,   0.0f,  0.32f, 0.80f,  5.0f, 0.0f, 6.0f }
};

// Disguises (Mau 27/11): props drawn over the face, sliding in and out
enum Disguise {
    D_NONE = 0, D_GROUCHO, D_CHAPLIN, D_PIRATE, D_SUNGLASSES, D_MONOCLE, D_PARTY, D_SPY,
    D_WIZARD, D_ROUNDGLASSES, D_ROBOT, D_ANON, D_FLAG, D_COUNT
};

// Space Invader sprites, 11 x 8, two frames
static const char *INVADER_A[8] = {
    "..X.....X..", "...X...X...", "..XXXXXXX..", ".XX.XXX.XX.",
    "XXXXXXXXXXX", "X.XXXXXXX.X", "X.X.....X.X", "...XX.XX..." };
static const char *INVADER_B[8] = {
    "..X.....X..", "X..X...X..X", "X.XXXXXXX.X", "XXX.XXX.XXX",
    "XXXXXXXXXXX", ".XXXXXXXXX.", "..X.....X..", ".X.......X." };

class BoxFace {
public:
    static const int SCREEN_W = 320;
    static const int SCREEN_H = 240;
    static const int CENTER_X = 160;
    static const int CENTER_Y = 120;

    static const int EYE_W = 52;
    static const int EYE_H = 84;
    static const int EYE_RADIUS = 26;
    static const int EYE_SPACING = 42;
    static const int PUPIL_RADIUS = 14;

    BoxMood currentMood = MOOD_NEUTRAL;
    FaceMoodParams cur = FACE_MOODS[MOOD_NEUTRAL];

    float lookTargetX = 0.0f;
    float lookTargetY = 0.0f;
    float lookCurX = 0.0f;
    float lookCurY = 0.0f;

    bool isBlinking = false;
    float blinkProgress = 0.0f;
    uint32_t blinkStartTime = 0;
    const uint32_t BLINK_DURATION = 135;

    uint32_t nextBlinkTime = 0;
    uint32_t nextSaccadeTime = 0;

    esphome::Color themeColor = esphome::Color(255, 255, 255); // white eyes (Mau 27/11)
    esphome::Color bgColor    = esphome::Color(10, 11, 13);    // Deep obsidian
    esphome::Color gridColor  = esphome::Color(22, 24, 28);    // Ambient grid
    esphome::Color propColor  = esphome::Color(235, 235, 240); // glasses, hats, moustaches
    esphome::Color red        = esphome::Color(220, 45, 45);
    esphome::Color gold       = esphome::Color(250, 200, 40);
    esphome::Color purple     = esphome::Color(95, 60, 200);
    esphome::Color pink       = esphome::Color(240, 70, 170);
    esphome::Color hatGrey    = esphome::Color(95, 98, 108);
    esphome::Color black      = esphome::Color(0, 0, 0);

    // idle life (moods, glances, Pong, Invaders, glitch, disguises), tap reactions, wake-up
    enum Behavior { B_NONE, B_LOOK, B_HAPPY, B_CURIOUS, B_YAWN, B_PONG, B_DISGUISE, B_INVADERS, B_GLITCH, B_JUMP, B_POP };
    bool idleMode = false;
    Behavior behavior = B_NONE;
    uint32_t behaviorEnd = 0;
    uint32_t nextBehaviorTime = 0;
    BoxMood reactMood = MOOD_NEUTRAL;
    uint32_t reactEnd = 0;
    float pop = 0.0f;
    // settings from HA (Mau 27/11): style 0 = emoji animations, 1 = pop heads, 2 = both; interval between animations
    int style = 0;
    uint32_t intervalMs = 25000;
    float popT = 0.0f;
    int popHead = 0, lastPopHead = -1;
    void set_style(int s) { style = s; }
    void set_interval_s(float s) { intervalMs = (uint32_t)(s * 1000.0f); }
    bool locked = false;  // top-left key freezes the current idle animation

    int disguise = D_NONE;
    int lastDisguise = D_NONE;
    float disguiseT = 0.0f;  // 0 = off, 1 = fully on

    // Pong: the eyes become paddles and a ball bounces between them
    enum PongPhase { P_OFF, P_IN, P_PLAY, P_OUT };
    PongPhase pongPhase = P_OFF;
    float pongT = 0.0f;  // 0 = eyes, 1 = paddles
    uint32_t pongEnd = 0;
    float ballX = 160, ballY = 120, ballVX = 3.4f, ballVY = 2.2f;
    float padLY = 120, padRY = 120;

    // Space Invaders: the eyes shrink away and two invaders march
    float invT = 0.0f;

    // Jump to MauXperia (Mau 27/11): eyes fly off the top, the clock page shows them, then they drop back in
    enum JumpPhase { J_NONE, J_OUT, J_AWAY, J_IN };
    JumpPhase jumpPhase = J_NONE;
    float jumpY = 0.0f;          // vertical offset of the whole face
    uint32_t jumpAwaySince = 0;
    bool away() const { return jumpPhase == J_AWAY; }
    bool is_locked() const { return locked; }
    void jump() {
        if (jumpPhase != J_NONE) return;
        pongPhase = P_OFF; pongT = 0.0f; invT = 0.0f; disguiseT = 0.0f; disguise = D_NONE;
        behavior = B_JUMP; jumpPhase = J_OUT; pop = 0.6f;
    }
    // the jump also has to move while the buttons are shown (the eyes view isn't being drawn then)
    void tick_jump() { updateJump(millis()); }
    void come_back() {
        if (jumpPhase == J_AWAY || jumpPhase == J_OUT) { jumpPhase = J_IN; jumpY = -260.0f; }
    }
    void updateJump(uint32_t now) {
        if (jumpPhase == J_OUT) { jumpY -= 14.0f + (-jumpY) * 0.12f; if (jumpY < -260.0f) { jumpPhase = J_AWAY; jumpAwaySince = now; } }
        else if (jumpPhase == J_AWAY) { if (!locked && now - jumpAwaySince > 20000) come_back(); }  // the clock never answered
        else if (jumpPhase == J_IN) {
            jumpY *= 0.82f;
            if (jumpY > -1.0f) { jumpY = 0.0f; jumpPhase = J_NONE; pop = 1.0f; trigger_blink();
                                 if (behavior == B_JUMP) behavior = B_NONE; nextBehaviorTime = now + 15000; }
        }
    }

    // mood set by a voice page (listening, thinking, replying): no idle behaviours there
    void set_mood(BoxMood m) {
        currentMood = m;
        if (idleMode) {
            idleMode = false;
            behavior = B_NONE;
            pongPhase = P_OFF; pongT = 0.0f; invT = 0.0f;
            disguiseT = 0.0f; disguise = D_NONE;
            popT = 0.0f;
        }
        jumpPhase = J_NONE; jumpY = 0.0f;
    }

    // the idle eyes view: the face picks its own moods
    void set_idle() {
        if (!idleMode) {
            idleMode = true;
            currentMood = MOOD_NEUTRAL;
            nextBehaviorTime = millis() + 6000;
            behavior = B_NONE;
        }
    }

    // wake word: eyes start shut and open into the next mood
    void wake() {
        cur.eyeScaleY = 0.05f;
        cur.squint = 0.0f;
        pongPhase = P_OFF; pongT = 0.0f; invT = 0.0f;
        disguiseT = 0.0f; disguise = D_NONE;
        popT = 0.0f;
        jumpPhase = J_NONE; jumpY = 0.0f;
        if (behavior != B_NONE && !locked) behavior = B_NONE;
        pop = 0.6f;
    }

    // a tap on the face: look at the finger, pop, smile for a moment
    void poke(int x, int y) {
        uint32_t now = millis();
        lookTargetX = std::max(-12.0f, std::min(12.0f, (x - CENTER_X) / 160.0f * 14.0f));
        lookTargetY = std::max(-8.0f, std::min(8.0f, (y - CENTER_Y) / 120.0f * 10.0f));
        nextSaccadeTime = now + 1400;
        pop = 1.0f;
        reactMood = (rand() % 3 == 0) ? MOOD_CURIOUS : MOOD_HAPPY;
        reactEnd = now + 1500;
        if (locked || jumpPhase != J_NONE) return;  // a locked animation or a jump survives taps
        if (pongPhase == P_IN || pongPhase == P_PLAY) pongPhase = P_OUT;
        if (behavior != B_DISGUISE) behavior = B_NONE;  // a disguise stays on through a tap
        nextBehaviorTime = now + 12000;
    }

    // top-left key: keep the current animation forever, press again to let the face roam
    void toggle_lock() {
        locked = !locked;
        pop = 0.5f;
        if (!locked) {  // unlocked: let the current animation finish soon
            uint32_t now = millis();
            behaviorEnd = now + 3000;
            pongEnd = now + 3000;
            nextBehaviorTime = now + 15000;
        }
    }

    void trigger_blink() {
        if (!isBlinking) {
            isBlinking = true;
            blinkStartTime = millis();
        }
    }

    BoxMood effectiveMood(uint32_t now) {
        if (now < reactEnd) return reactMood;
        if (!idleMode) return currentMood;
        switch (behavior) {
            case B_HAPPY: return MOOD_HAPPY;
            case B_CURIOUS: return MOOD_CURIOUS;
            case B_YAWN: return MOOD_SLEEPY;
            case B_DISGUISE:
                switch (disguise) {
                    case D_GROUCHO: case D_PIRATE: case D_PARTY: return MOOD_HAPPY;
                    case D_SPY: return MOOD_FOCUSED;
                    case D_ROUNDGLASSES: return MOOD_CURIOUS;
                    default: return MOOD_NEUTRAL;
                }
            default: return MOOD_NEUTRAL;
        }
    }

    void updateIdle(uint32_t now) {
        if (locked) {  // stretch whatever runs now; nothing new starts
            behaviorEnd = now + 60000;
            nextBehaviorTime = now + 60000;
            if (behavior == B_PONG && pongPhase == P_PLAY) pongEnd = now + 60000;
        }
        if (behavior != B_NONE && behavior != B_PONG && behavior != B_JUMP && now > behaviorEnd) {
            if (behavior == B_YAWN) trigger_blink();
            if (behavior == B_GLITCH) wake();  // "reboot" with a fresh blink
            behavior = B_NONE;
        }
        if (behavior == B_PONG && pongPhase == P_OFF) behavior = B_NONE;
        if (behavior == B_NONE && disguiseT <= 0.0f && invT <= 0.0f && popT <= 0.0f && now > nextBehaviorTime) {
            int r = rand() % 20;
            if (style == 1 || (style == 2 && rand() % 2)) {  // a pop head
                behavior = B_POP; behaviorEnd = now + 8000;
                do { popHead = rand() % pop::COUNT; } while (popHead == lastPopHead && pop::COUNT > 1);
                lastPopHead = popHead;
            }
            else if (r < 2) { behavior = B_PONG; pongPhase = P_IN; pongEnd = now + 14000;
                         ballX = CENTER_X; ballY = CENTER_Y; ballVX = (rand() % 2) ? 3.4f : -3.4f; ballVY = 2.2f; }
            else if (r < 4) { behavior = B_INVADERS; behaviorEnd = now + 12000; }
            else if (r < 5) { behavior = B_GLITCH; behaviorEnd = now + 1400; }
            else if (r < 15) {
                behavior = B_DISGUISE; behaviorEnd = now + 8000;
                do { disguise = 1 + rand() % (D_COUNT - 1); } while (disguise == lastDisguise);
                lastDisguise = disguise;
            }
            else if (r < 17) { behavior = B_LOOK; behaviorEnd = now + 5000; }
            else if (r < 18) { behavior = B_HAPPY; behaviorEnd = now + 3500; }
            else if (r < 19) { behavior = B_CURIOUS; behaviorEnd = now + 3000; }
            else { behavior = B_YAWN; behaviorEnd = now + 2800; }
            nextBehaviorTime = now + intervalMs / 2 + (rand() % (intervalMs + 1));  // the HA interval, +-50 %
        }
        // props and invaders slide in while their behaviour runs, then away
        bool wear = behavior == B_DISGUISE;
        disguiseT = std::max(0.0f, std::min(1.0f, disguiseT + (wear ? 0.07f : -0.07f)));
        if (disguiseT <= 0.0f && !wear) disguise = D_NONE;
        invT = std::max(0.0f, std::min(1.0f, invT + (behavior == B_INVADERS ? 0.06f : -0.06f)));
        popT = std::max(0.0f, std::min(1.0f, popT + (behavior == B_POP ? 0.08f : -0.08f)));
    }

    void updatePong(uint32_t now) {
        if (pongPhase == P_IN) { pongT += 0.06f; if (pongT >= 1.0f) { pongT = 1.0f; pongPhase = P_PLAY; } }
        else if (pongPhase == P_OUT) { pongT -= 0.06f; if (pongT <= 0.0f) { pongT = 0.0f; pongPhase = P_OFF; } }
        else if (pongPhase == P_PLAY) {
            if (now > pongEnd) { pongPhase = P_OUT; return; }
            ballX += ballVX; ballY += ballVY;
            if (ballY < 6) { ballY = 6; ballVY = -ballVY; }
            if (ballY > SCREEN_H - 6) { ballY = SCREEN_H - 6; ballVY = -ballVY; }
            // paddles chase the ball, a bit slower than it so they miss sometimes
            float lt = ballVX < 0 ? ballY : (float)CENTER_Y, rt = ballVX > 0 ? ballY : (float)CENTER_Y;
            padLY += std::max(-2.6f, std::min(2.6f, lt - padLY));
            padRY += std::max(-2.6f, std::min(2.6f, rt - padRY));
            const float halfH = 22.0f;
            if (ballX < 26 && ballVX < 0) {
                if (fabsf(ballY - padLY) <= halfH + 6) { ballVX = -ballVX * 1.04f; ballVY += (ballY - padLY) * 0.08f; }
                else if (ballX < 0) { ballX = CENTER_X; ballY = CENTER_Y; ballVX = 3.4f; ballVY = 2.2f; }
            }
            if (ballX > SCREEN_W - 26 && ballVX > 0) {
                if (fabsf(ballY - padRY) <= halfH + 6) { ballVX = -ballVX * 1.04f; ballVY += (ballY - padRY) * 0.08f; }
                else if (ballX > SCREEN_W) { ballX = CENTER_X; ballY = CENTER_Y; ballVX = -3.4f; ballVY = -2.2f; }
            }
            ballVX = std::max(-7.0f, std::min(7.0f, ballVX));
            ballVY = std::max(-5.0f, std::min(5.0f, ballVY));
        }
    }

    void update() {
        uint32_t now = millis();

        if (idleMode) updateIdle(now);
        updatePong(now);
        updateJump(now);

        // Autonomous Micro-Saccades; wide while "looking around", sideways darts for the spy
        if (now > nextSaccadeTime) {
            bool lookAround = idleMode && behavior == B_LOOK;
            bool spy = idleMode && behavior == B_DISGUISE && disguise == D_SPY;
            float range = (lookAround || spy) ? 1.6f : 1.0f;
            lookTargetX = ((float)(rand() % 200 - 100) / 100.0f) * 12.0f * range;
            lookTargetY = spy ? 0.0f : ((float)(rand() % 200 - 100) / 100.0f) * 8.0f * range;
            if (spy) lookTargetX = (lookCurX > 0 ? -1.0f : 1.0f) * 18.0f;
            nextSaccadeTime = now + ((lookAround || spy) ? 700 + (rand() % 900) : 1600 + (rand() % 3200));
        }

        lookCurX += (lookTargetX - lookCurX) * 0.16f;
        lookCurY += (lookTargetY - lookCurY) * 0.16f;

        // Autonomous Blinking
        if (now > nextBlinkTime && !isBlinking) {
            trigger_blink();
            nextBlinkTime = now + 2800 + (rand() % 4200);
        }

        if (isBlinking) {
            uint32_t elapsed = now - blinkStartTime;
            if (elapsed >= BLINK_DURATION) {
                isBlinking = false;
                blinkProgress = 0.0f;
            } else {
                float t = (float)elapsed / (float)BLINK_DURATION;
                blinkProgress = sinf(t * 3.14159265f);
            }
        }

        pop *= 0.86f;

        // Smooth Mood Parameter Transition
        const FaceMoodParams &target = FACE_MOODS[effectiveMood(now)];
        cur.leftSlant      += (target.leftSlant      - cur.leftSlant)      * 0.15f;
        cur.rightSlant     += (target.rightSlant     - cur.rightSlant)     * 0.15f;
        cur.browLeftY      += (target.browLeftY      - cur.browLeftY)      * 0.15f;
        cur.browRightY     += (target.browRightY     - cur.browRightY)     * 0.15f;
        cur.browLeftAngle  += (target.browLeftAngle  - cur.browLeftAngle)  * 0.15f;
        cur.browRightAngle += (target.browRightAngle - cur.browRightAngle) * 0.15f;
        cur.eyeScaleY      += (target.eyeScaleY      - cur.eyeScaleY)      * 0.15f;
        cur.squint         += (target.squint         - cur.squint)         * 0.15f;
        cur.mouthW         += (target.mouthW         - cur.mouthW)         * 0.15f;
        cur.mouthCurve     += (target.mouthCurve     - cur.mouthCurve)     * 0.15f;
        cur.mouthOpen      += (target.mouthOpen      - cur.mouthOpen)      * 0.15f;
    }

    template <typename T>
    void drawCapsule(T &it, int cx, int cy, int w, int h, esphome::Color col) {
        int r = w / 2;
        int topY = cy - h / 2 + r;
        int botY = cy + h / 2 - r;
        if (botY < topY) botY = topY;

        it.filled_rectangle(cx - r, topY, w, botY - topY, col);
        it.filled_circle(cx, topY, r, col);
        it.filled_circle(cx, botY, r, col);
    }

    template <typename T>
    void ring(T &it, int cx, int cy, int r, int thick, esphome::Color col) {
        for (int i = 0; i < thick; i++) it.circle(cx, cy, r + i, col);
    }

    template <typename T>
    void thickLine(T &it, int x1, int y1, int x2, int y2, int thick, esphome::Color col) {
        for (int d = -thick / 2; d <= thick / 2; d++) { it.line(x1 + d, y1, x2 + d, y2, col); it.line(x1, y1 + d, x2, y2 + d, col); }
    }

    bool robotEyes() const { return disguise == D_ROBOT && disguiseT > 0.5f; }

    template <typename T>
    void drawEye(T &it, int centerX, int centerY, bool isRight) {
        float hScale = std::max(0.04f, cur.eyeScaleY * (1.0f - blinkProgress * 0.96f)) * (1.0f + pop * 0.22f);
        if (invT > 0.0f) hScale *= std::max(0.0f, 1.0f - invT * 2.0f);  // shrink away for the invaders
        if (invT >= 0.5f) return;
        int w = (int)(EYE_W * (1.0f + pop * 0.12f));
        int h = (int)(EYE_H * hScale);
        if (h < 4) h = 4;

        int eyeX = centerX + (int)(lookCurX * 0.7f);
        int eyeY = centerY + (int)(lookCurY * 0.7f);

        // Pong morph: the eye slides to the screen edge and thins into a paddle
        if (pongT > 0.0f) {
            float t = pongT;
            int padX = isRight ? SCREEN_W - 16 : 16;
            int padY = (int)(isRight ? padRY : padLY);
            eyeX = (int)(eyeX + (padX - eyeX) * t);
            eyeY = (int)(eyeY + (padY - eyeY) * t);
            w = (int)(w + (10 - w) * t);
            h = (int)(h + (44 - h) * t);
        }

        // Robot: square LED eyes with a pixel grid and a square pupil
        if (robotEyes()) {
            int s = 54, sh = std::max(4, (int)(54 * hScale));
            it.filled_rectangle(eyeX - s / 2, eyeY - sh / 2, s, sh, themeColor);
            for (int gx = eyeX - s / 2 + 6; gx < eyeX + s / 2; gx += 6) it.line(gx, eyeY - sh / 2, gx, eyeY + sh / 2, bgColor);
            for (int gy = eyeY - sh / 2 + 6; gy < eyeY + sh / 2; gy += 6) it.line(eyeX - s / 2, gy, eyeX + s / 2, gy, bgColor);
            if (sh > 20) it.filled_rectangle(eyeX - 8 + (int)(lookCurX * 0.6f), eyeY - 8 + (int)(lookCurY * 0.6f), 16, 16, bgColor);
            return;
        }

        // 1. Draw Outer Capsule in Theme Color
        drawCapsule(it, eyeX, eyeY, w, h, themeColor);
        if (pongT > 0.3f) return;  // paddles have no pupil or brow

        // 2. Pure Black Core (Pupil) clamped within capsule bounds
        if (blinkProgress < 0.7f) {
            int pupilR = (int)(PUPIL_RADIUS * (1.0f - blinkProgress * 0.3f));
            if (pupilR < 2) pupilR = 2;

            int rawPupilX = (int)(lookCurX * 0.7f);
            int rawPupilY = (int)(lookCurY * 0.7f);

            int maxOffsetX = (w / 2) - pupilR - 2;
            int maxOffsetY = (h / 2) - pupilR - 2;
            if (maxOffsetX < 0) maxOffsetX = 0;
            if (maxOffsetY < 0) maxOffsetY = 0;

            int clampedX = std::max(-maxOffsetX, std::min(maxOffsetX, rawPupilX));
            int clampedY = std::max(-maxOffsetY, std::min(maxOffsetY, rawPupilY));

            it.filled_circle(eyeX + clampedX, eyeY + clampedY, pupilR, bgColor);
        }

        // 3. Warm Smile Squint Cutout (bottom eyelid)
        if (cur.squint > 0.05f && blinkProgress < 0.25f) {
            int cutoutH = (int)(26.0f * cur.squint);
            int cutoutTop = eyeY + h / 2 - cutoutH;
            it.filled_rectangle(eyeX - w / 2 - 2, cutoutTop, w + 4, cutoutH + 4, bgColor);
        }

        // 4. Floating Architectural Brow Line (Groucho / Dumbledore: thick and bushy)
        float browOffsetY = isRight ? cur.browRightY : cur.browLeftY;
        float browAngle   = isRight ? cur.browRightAngle : cur.browLeftAngle;

        int browCenterX = centerX + (int)(lookCurX * 0.4f);
        int browCenterY = centerY + (int)browOffsetY + (int)(lookCurY * 0.4f);

        float halfLen = (float)EYE_W * 0.44f;
        float cosA = cosf(browAngle);
        float sinA = sinf(browAngle);

        int x1 = browCenterX - (int)(halfLen * cosA);
        int y1 = browCenterY - (int)(halfLen * sinA);
        int x2 = browCenterX + (int)(halfLen * cosA);
        int y2 = browCenterY + (int)(halfLen * sinA);

        bool bushy = disguise == D_GROUCHO || disguise == D_WIZARD;
        int thick = bushy ? (int)(1 + 5 * disguiseT) : 1;
        esphome::Color browCol = (disguise == D_WIZARD && disguiseT > 0.5f) ? propColor : themeColor;
        for (int d = -thick; d <= thick; d++) it.line(x1, y1 + d, x2, y2 + d, browCol);
    }

    // a real mouth: smile curve, open when happy or surprised; a vertical slice per column
    template <typename T>
    void drawMouth(T &it, int cx, int cy) {
        if (disguise == D_ROBOT && disguiseT > 0.5f) {  // robot: a speaker grille with a scanner light
            uint32_t now = millis();
            it.rectangle(cx - 40, cy - 8, 80, 16, themeColor);
            int pos = (int)(30 * sinf(now / 260.0f));
            it.filled_rectangle(cx + pos - 8, cy - 5, 16, 10, red);
            return;
        }
        float w = std::max(3.0f, cur.mouthW + pop * 4.0f);
        float open = cur.mouthOpen + pop * 6.0f;
        if (disguise == D_SUNGLASSES && disguiseT > 0.5f) { open = 0.0f; }  // cool smirk
        for (int dx = -(int)w; dx <= (int)w; dx++) {
            float u = dx / w;
            float bulge = 1.0f - u * u;
            float c = cur.mouthCurve * bulge;
            if (disguise == D_SUNGLASSES && disguiseT > 0.5f) c = (dx + w) * 0.25f;  // lopsided smirk
            float half = std::max(1.5f, open * 0.5f * sqrtf(std::max(0.0f, bulge)));
            int y0 = cy + (int)(c - (open > 1.0f ? half * 0.4f : half));
            int y1 = cy + (int)(c + half);
            it.line(cx + dx, y0, cx + dx, y1, themeColor);
        }
    }

    template <typename T>
    void drawInvader(T &it, int cx, int cy, bool frameB) {
        const char **spr = frameB ? INVADER_B : INVADER_A;
        const int px = 4;
        for (int r = 0; r < 8; r++)
            for (int c = 0; c < 11; c++)
                if (spr[r][c] == 'X') it.filled_rectangle(cx - 22 + c * px, cy - 16 + r * px, px, px, themeColor);
    }

    // props per disguise; t slides them in (hats drop from above)
    template <typename T>
    void drawDisguise(T &it, int leftEyeX, int rightEyeX, int mouthX, int mouthY) {
        if (disguise == D_NONE || disguiseT <= 0.0f) return;
        float t = disguiseT;
        uint32_t now = millis();
        int lx = (int)(lookCurX * 0.7f), ly = (int)(lookCurY * 0.7f);
        int hx = CENTER_X + (int)(lookCurX * 0.4f);
        int drop = (int)((1.0f - t) * -150);
        int ey = CENTER_Y + ly;

        switch (disguise) {
            case D_GROUCHO: {
                int gy = ey + drop;
                ring(it, leftEyeX + lx, gy, 36, 4, propColor);
                ring(it, rightEyeX + lx, gy, 36, 4, propColor);
                it.filled_rectangle(leftEyeX + lx + 38, gy - 6, rightEyeX - leftEyeX - 76, 4, propColor);
                it.filled_rectangle(leftEyeX + lx - 58, gy - 8, 20, 4, propColor);
                it.filled_rectangle(rightEyeX + lx + 38, gy - 8, 20, 4, propColor);
                {  // the big novelty nose hanging from the bridge (what makes it Groucho)
                    const esphome::Color nose(240, 170, 150), noseDark(200, 120, 105);
                    int nx = CENTER_X + lx, ntop = gy - 4, ntip = mouthY - 18;
                    it.filled_triangle(nx - 7, ntop, nx + 7, ntop, nx + 16, ntip, nose);
                    it.filled_triangle(nx - 7, ntop, nx - 14, ntip, nx + 16, ntip, nose);
                    it.filled_circle(nx + 1, ntip, 17, nose);
                    it.filled_circle(nx - 9, ntip + 6, 5, noseDark);   // nostrils
                    it.filled_circle(nx + 11, ntip + 6, 5, noseDark);
                }
                int mw = (int)(30 * t), my = mouthY - 10;
                it.filled_rectangle(mouthX - mw, my - 5, mw * 2, 9, propColor);
                it.filled_circle(mouthX - mw, my, 6, propColor);
                it.filled_circle(mouthX + mw, my, 6, propColor);
                break;
            }
            case D_CHAPLIN: {
                int brimY = CENTER_Y - 62 + drop;
                it.filled_rectangle(hx - 66, brimY, 132, 7, propColor);
                for (int dy = 0; dy <= 40; dy++) {
                    float k = dy / 40.0f;
                    int hw = (int)(44 * sqrtf(std::max(0.0f, 1.0f - k * k)));
                    it.line(hx - hw, brimY - dy, hx + hw, brimY - dy, propColor);
                }
                it.filled_rectangle(hx - 44, brimY - 10, 88, 5, bgColor);
                int mw = (int)(9 * t);
                if (mw > 0) it.filled_rectangle(mouthX - mw, mouthY - 13, mw * 2, 8, propColor);
                break;
            }
            case D_PIRATE: {
                int by = 30 + drop;  // red bandana with a knot
                it.filled_rectangle(hx - 80, by, 160, 22, red);
                for (int i = 0; i < 6; i++) it.filled_circle(hx - 60 + i * 24, by + 11, 3, propColor);
                it.filled_triangle(hx + 80, by + 4, hx + 108, by - 6, hx + 100, by + 18, red);
                it.filled_triangle(hx + 80, by + 14, hx + 106, by + 30, hx + 96, by + 6, red);
                // green parrot on the "shoulder" (bottom right), bobbing its head
                if (t > 0.4f) {
                    const esphome::Color green(40, 190, 70), dark(20, 120, 45), beak(250, 150, 30);
                    int px = 268 + (int)((1.0f - t) * 80), py = 196 + (int)(3 * sinf(now / 220.0f));
                    it.filled_triangle(px + 4, py + 18, px + 26, py + 44, px + 12, py + 46, dark);   // tail
                    it.filled_circle(px, py + 10, 17, green);                                         // body
                    it.filled_circle(px + 6, py + 12, 9, dark);                                       // wing
                    it.filled_circle(px - 6, py - 14, 12, green);                                     // head
                    it.filled_triangle(px - 17, py - 18, px - 30, py - 10, px - 17, py - 6, beak);  // beak
                    it.filled_circle(px - 9, py - 17, 3, propColor);                                  // eye
                    it.filled_circle(px - 9, py - 17, 1, black);
                    it.filled_rectangle(px - 20, 236, 40, 4, hatGrey);                                // shoulder
                }
                int pr = (int)(34 * t);  // eye patch on the right eye
                if (pr > 2) {
                    it.filled_circle(rightEyeX + lx, ey, pr, black);
                    ring(it, rightEyeX + lx, ey, pr, 2, hatGrey);
                    if (t > 0.8f) {
                        thickLine(it, rightEyeX + lx - 24, ey - 24, hx - 60, by + 22, 3, black);
                        thickLine(it, rightEyeX + lx + 24, ey - 24, hx + 76, by + 22, 3, black);
                    }
                }
                break;
            }
            case D_SUNGLASSES: {
                int gy = ey - 4 + drop;  // pixel shades slide down
                const esphome::Color lens(18, 18, 22);
                it.filled_rectangle(leftEyeX + lx - 34, gy - 20, 68, 38, lens);
                it.filled_rectangle(rightEyeX + lx - 34, gy - 20, 68, 38, lens);
                it.filled_rectangle(leftEyeX + lx - 40, gy - 24, rightEyeX - leftEyeX + 80, 7, black);
                it.rectangle(leftEyeX + lx - 34, gy - 20, 68, 38, hatGrey);
                it.rectangle(rightEyeX + lx - 34, gy - 20, 68, 38, hatGrey);
                // pixel glint
                it.filled_rectangle(leftEyeX + lx - 24, gy - 12, 8, 4, propColor);
                it.filled_rectangle(rightEyeX + lx - 24, gy - 12, 8, 4, propColor);
                break;
            }
            case D_MONOCLE: {
                // top hat
                int brimY = 58 + drop;
                it.filled_rectangle(hx - 60, brimY, 120, 7, propColor);
                it.filled_rectangle(hx - 38, brimY - 52, 76, 52, propColor);
                it.filled_rectangle(hx - 38, brimY - 14, 76, 8, red);
                // monocle on the right eye with its chain
                if (t > 0.6f) {
                    ring(it, rightEyeX + lx, ey, 34, 3, gold);
                    for (int i = 0; i < 6; i++) it.filled_circle(rightEyeX + lx + 30 + i * 3, ey + 36 + i * 12, 2, gold);
                }
                // twirly moustache
                int mw = (int)(26 * t), my = mouthY - 10;
                if (mw > 4) {
                    it.filled_rectangle(mouthX - mw, my - 3, mw * 2, 6, propColor);
                    it.circle(mouthX - mw - 4, my - 6, 6, propColor);
                    it.circle(mouthX + mw + 4, my - 6, 6, propColor);
                }
                break;
            }
            case D_PARTY: {
                int baseY = 64 + drop;  // cone hat with stripes and a pompom
                it.filled_triangle(hx - 32, baseY, hx + 32, baseY, hx, baseY - 70, pink);
                for (int i = 1; i < 4; i++) {
                    int yy = baseY - i * 17, hw = 32 - i * 8;
                    it.filled_rectangle(hx - hw, yy, hw * 2, 4, gold);
                }
                it.filled_circle(hx, baseY - 72, 8, gold);
                // confetti falling across the screen
                if (t > 0.5f) {
                    const esphome::Color cols[4] = {gold, pink, themeColor, red};
                    for (int i = 0; i < 18; i++) {
                        int cx = (i * 53 + 17) % SCREEN_W + (int)(6 * sinf(now / 300.0f + i));
                        int cy = (int)((now / 14 + i * 41) % (SCREEN_H + 20)) - 10;
                        it.filled_rectangle(cx, cy, 5, 3 + (i % 2) * 2, cols[i % 4]);
                    }
                }
                break;
            }
            case D_SPY: {
                int brimY = 72 + drop;  // fedora pulled low
                it.filled_rectangle(hx - 78, brimY, 156, 7, hatGrey);
                it.filled_rectangle(hx - 46, brimY - 34, 92, 34, hatGrey);
                it.filled_triangle(hx - 14, brimY - 34, hx + 14, brimY - 34, hx, brimY - 24, bgColor);  // pinch
                it.filled_rectangle(hx - 46, brimY - 10, 92, 6, black);
                break;
            }
            case D_WIZARD: {
                int baseY = 66 + drop;  // tall bent wizard hat with stars
                it.filled_rectangle(hx - 70, baseY, 140, 8, purple);
                it.filled_triangle(hx - 48, baseY, hx + 48, baseY, hx + 14, baseY - 80, purple);
                it.filled_triangle(hx + 2, baseY - 66, hx + 24, baseY - 74, hx + 48, baseY - 52, purple);  // bent tip
                const int sx[3] = {-20, 10, -2}, sy[3] = {-18, -34, -54};
                for (int i = 0; i < 3; i++) {
                    int cx = hx + sx[i], cy = baseY + sy[i];
                    it.filled_rectangle(cx - 5, cy - 1, 11, 3, gold);
                    it.filled_rectangle(cx - 1, cy - 5, 3, 11, gold);
                }
                // long white beard (covers the mouth), moustache on top
                if (t > 0.3f) {
                    int by = mouthY - 14, len = (int)(70 * t);
                    it.filled_triangle(mouthX - 58, by, mouthX + 58, by, mouthX, by + len + 20, propColor);
                    for (int i = 0; i < 5; i++) it.filled_circle(mouthX - 46 + i * 23, by + 6, 13, propColor);
                    it.filled_rectangle(mouthX - 26, by - 6, 52, 8, propColor);
                    it.filled_rectangle(mouthX - 12, by + 6, 24, 4, bgColor);  // a hint of mouth
                }
                break;
            }
            case D_ROUNDGLASSES: {
                int gy = ey + drop;  // thin round glasses
                ring(it, leftEyeX + lx, gy, 33, 2, hatGrey);
                ring(it, rightEyeX + lx, gy, 33, 2, hatGrey);
                it.filled_rectangle(leftEyeX + lx + 34, gy - 3, rightEyeX - leftEyeX - 68, 3, hatGrey);
                it.filled_rectangle(leftEyeX + lx - 52, gy - 5, 18, 3, hatGrey);
                it.filled_rectangle(rightEyeX + lx + 34, gy - 5, 18, 3, hatGrey);
                break;
            }
            case D_ROBOT: {
                // antenna with a blinking light, ear bolts (eyes and mouth change in drawEye / drawMouth)
                int topY = 66 + drop;
                thickLine(it, hx, topY, hx, topY - 36, 3, hatGrey);
                it.filled_circle(hx, topY - 40, 7, ((now / 500) % 2) ? red : gold);
                if (t > 0.5f) {
                    it.filled_rectangle(4, CENTER_Y - 20, 12, 40, hatGrey);
                    it.filled_rectangle(SCREEN_W - 16, CENTER_Y - 20, 12, 40, hatGrey);
                    it.filled_circle(10, CENTER_Y, 3, bgColor);
                    it.filled_circle(SCREEN_W - 10, CENTER_Y, 3, bgColor);
                }
                break;
            }
            case D_ANON: {
                // Anonymous: the face hides behind a white smiling mask (slit eyes, arched brows, curled moustache, goatee)
                int my = (int)((1.0f - t) * 260);  // mask rises from below
                int cxm = CENTER_X, cym = 124 + my;
                for (int dy = -112; dy <= 112; dy++) {
                    float k = dy / 112.0f;
                    int hw = (int)(92 * sqrtf(std::max(0.0f, 1.0f - k * k)) * (dy > 40 ? 1.0f - (dy - 40) / 260.0f : 1.0f));
                    it.line(cxm - hw, cym + dy, cxm + hw, cym + dy, propColor);
                }
                const esphome::Color ink(15, 15, 18), cheek(235, 140, 150);
                for (int s2 = -1; s2 <= 1; s2 += 2) {
                    int ex = cxm + s2 * 40, eyY = cym - 14;
                    for (int dx = -20; dx <= 20; dx++) {  // slit eye, thicker in the middle
                        float u = dx / 20.0f; int hh = (int)(5 * (1.0f - u * u)) + 1;
                        it.line(ex + dx, eyY - hh + (int)(3 * u * s2), ex + dx, eyY + hh + (int)(3 * u * s2), ink);
                    }
                    for (int dx = -28; dx <= 22; dx++) {  // arched brow rising to the outside
                        float u = (dx + 3) / 25.0f; int by = eyY - 22 - (int)(10 * (1.0f - u * u)) - (s2 * dx > 0 ? s2 * dx / 4 : 0);
                        it.line(ex + s2 * dx, by, ex + s2 * dx, by + 4, ink);
                    }
                    it.filled_circle(ex + s2 * 10, cym + 26, 12, cheek);
                }
                for (int dx = -46; dx <= 46; dx++) {  // curled moustache: thick at the middle, ends flick up
                    float u = dx / 46.0f; int yy = cym + 40 - (int)(18 * u * u * u * u);
                    int th = (int)(6 * (1.0f - fabsf(u))) + 2;
                    it.line(cxm + dx, yy - th, cxm + dx, yy + th / 2, ink);
                }
                for (int dx = -34; dx <= 34; dx++) {  // thin smile
                    float u = dx / 34.0f; int yy = cym + 56 + (int)(8 * (1.0f - u * u)) - (int)(10 * u * u);
                    it.line(cxm + dx, yy, cxm + dx, yy + 2, ink);
                }
                it.filled_rectangle(cxm - 2, cym + 70, 4, 34, ink);       // goatee
                it.filled_triangle(cxm - 6, cym + 100, cxm + 6, cym + 100, cxm, cym + 112, ink);
                break;
            }
            case D_FLAG: {
                // Jolly Roger: a black flag rises on a pole and waves, skull and crossbones on it
                int rise = (int)((1.0f - t) * 240);
                const esphome::Color cloth(24, 24, 28);
                it.filled_rectangle(26, 8 + rise, 6, 232, hatGrey);                 // pole
                it.filled_circle(29, 8 + rise, 6, gold);                             // finial
                const int fx0 = 32, fx1 = 302, fy0 = 22, fy1 = 186;
                for (int x = fx0; x <= fx1; x++) {
                    float a = (float)(x - fx0) / (fx1 - fx0);
                    int yo = rise + (int)(7.0f * a * sinf(now / 240.0f - x / 28.0f));
                    it.line(x, fy0 + yo, x, fy1 + yo, cloth);
                    it.draw_pixel_at(x, fy0 + yo, propColor);
                    it.draw_pixel_at(x, fy1 + yo, propColor);
                }
                int sx = 170, cxo = rise + (int)(7.0f * ((float)(sx - fx0) / (fx1 - fx0)) * sinf(now / 240.0f - sx / 28.0f));
                int sy = 92 + cxo;
                // crossbones behind the skull
                thickLine(it, sx - 56, sy + 58, sx + 56, sy + 2, 9, propColor);
                thickLine(it, sx - 56, sy + 2, sx + 56, sy + 58, 9, propColor);
                const int kx[4] = {-58, 58, -58, 58}, ky[4] = {58, 2, 2, 58};
                for (int i = 0; i < 4; i++) { it.filled_circle(sx + kx[i] - 4, sy + ky[i] - 3, 7, propColor);
                                              it.filled_circle(sx + kx[i] + 4, sy + ky[i] + 3, 7, propColor); }
                // skull
                it.filled_circle(sx, sy, 34, propColor);
                it.filled_rectangle(sx - 20, sy + 20, 40, 24, propColor);
                it.filled_circle(sx - 13, sy - 2, 10, cloth);
                it.filled_circle(sx + 13, sy - 2, 10, cloth);
                it.filled_triangle(sx - 5, sy + 18, sx + 5, sy + 18, sx, sy + 10, cloth);
                for (int i = -1; i <= 1; i++) it.filled_rectangle(sx + i * 10 - 1, sy + 30, 2, 14, cloth);  // teeth
                break;
            }
            default: break;
        }
    }

    // a second of corny robot glitch: scanlines, torn bands, static
    template <typename T>
    void drawGlitch(T &it) {
        for (int y = 0; y < SCREEN_H; y += 4) it.line(0, y, SCREEN_W, y, bgColor);
        for (int i = 0; i < 10; i++) {
            int y = rand() % SCREEN_H, h = 2 + rand() % 6, x = rand() % SCREEN_W, w = 20 + rand() % 140;
            it.filled_rectangle(x, y, w, h, (i % 3 == 0) ? red : ((i % 3 == 1) ? themeColor : bgColor));
        }
        for (int i = 0; i < 60; i++) it.draw_pixel_at(rand() % SCREEN_W, rand() % SCREEN_H, propColor);
    }

    template <typename T>
    void draw(T &it) {
        it.fill(bgColor);
        uint32_t now = millis();

        // Fine ambient grid
        for (int x = 20; x < SCREEN_W; x += 20) {
            it.line(x, 0, x, SCREEN_H, gridColor);
        }
        for (int y = 20; y < SCREEN_H; y += 20) {
            it.line(0, y, SCREEN_W, y, gridColor);
        }

        int leftEyeX  = CENTER_X - (EYE_W / 2 + EYE_SPACING / 2);
        int rightEyeX = CENTER_X + (EYE_W / 2 + EYE_SPACING / 2);

        int oy = (int)jumpY;
        if (jumpPhase == J_AWAY) {  // empty screen: three dots pointing up to where the eyes went
            for (int i = 0; i < 3; i++) it.filled_circle(CENTER_X, 70 + i * 40, 4 + i * 2, gridColor);
            if (idleMode && behavior == B_GLITCH) drawGlitch(it);
            return;
        }
        if (popT > 0.0f) {  // pop head drops in from the top (and back up)
            float k = 1.0f - popT;
            pop::draw(it, popHead, blinkProgress, lookCurX, lookCurY, oy - (int)(k * k * 260), now);
            return;
        }
        drawEye(it, leftEyeX, CENTER_Y + oy, false);
        drawEye(it, rightEyeX, CENTER_Y + oy, true);

        int mouthX = CENTER_X + (int)(lookCurX * 0.3f);
        int mouthY = CENTER_Y + oy + EYE_H / 2 + 22 + (int)(lookCurY * 0.3f);
        if (invT >= 0.5f) {
            // two invaders marching side to side, a little cannon below
            int step = (int)((now / 450) % 8);
            int off = (step < 4 ? step : 8 - step) * 10 - 20;
            bool frameB = (now / 450) % 2;
            drawInvader(it, leftEyeX + off, CENTER_Y - 20, frameB);
            drawInvader(it, rightEyeX + off, CENTER_Y - 20, !frameB);
            int gx = CENTER_X + (int)(60 * sinf(now / 700.0f));
            it.filled_rectangle(gx - 12, 214, 24, 8, themeColor);
            it.filled_rectangle(gx - 3, 208, 6, 6, themeColor);
            int shot = (int)(now % 900) / 6;
            if (shot < 120) it.filled_rectangle(gx - 1, 204 - shot, 2, 8, propColor);
        } else if (pongT > 0.9f) {
            // net and ball
            for (int y = 4; y < SCREEN_H; y += 16) it.filled_rectangle(CENTER_X - 1, y, 3, 8, gridColor);
            it.filled_circle((int)ballX, (int)ballY, 6, themeColor);
        } else if (pongT < 0.3f && invT <= 0.0f) {
            drawMouth(it, mouthX, mouthY);
            drawDisguise(it, leftEyeX, rightEyeX, mouthX, mouthY);
        }
        if (idleMode && behavior == B_GLITCH) drawGlitch(it);
    }
};

static BoxFace global_box_face;
