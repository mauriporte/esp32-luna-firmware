#pragma once
// Joint Remote page for the ESP32-S3-BOX (320x240): device chips on top, then either the pairing screen
// (button, then a 6-digit keypad) or the remote (D-pad + OK, 4 keys left, 4 keys right).
// jr::draw() paints it; jr::hit() turns a tap into an action. The layout lives only here, so both always agree.
#include "esphome.h"
#include "jr.h"

namespace jr {
using esphome::Color;

// what a tap means
enum Act { NONE, CHIP, PAIR, DIGIT, BACKSPACE, CANCEL, KEY };
struct Hit { Act act; int arg; const char *key; };

static const char *LEFT_KEYS[4] = {"back", "home", "mute", "previous"};
static const char *LEFT_LBL[4] = {"Atrás", "Inicio", "Mute", "Anterior"};
static const char *RIGHT_KEYS[4] = {"volume_up", "volume_down", "play_pause", "next"};
static const char *RIGHT_LBL[4] = {"Vol +", "Vol -", "Play", "Siguiente"};

inline Hit hit(int x, int y, bool show_pairing, bool pairing) {
  if (y < 34) return {CHIP, std::min(N - 1, std::max(0, x / 80)), nullptr};
  if (show_pairing) {
    if (!pairing) return (x >= 50 && x < 270 && y >= 90 && y < 150) ? Hit{PAIR, 0, nullptr} : Hit{NONE, 0, nullptr};
    if (x < 40 || x >= 280 || y < 76) return {NONE, 0, nullptr};
    int col = (x - 40) / 80, row = (y - 76) / 40;
    if (row > 3) return {NONE, 0, nullptr};
    int k = row * 3 + col;
    if (k < 9) return {DIGIT, k + 1, nullptr};
    if (k == 10) return {DIGIT, 0, nullptr};
    return k == 9 ? Hit{BACKSPACE, 0, nullptr} : Hit{CANCEL, 0, nullptr};
  }
  int dx = x - 160, dy = y - 140;
  if (dx * dx + dy * dy <= 22 * 22) return {KEY, 0, "center"};
  if (dx * dx + dy * dy <= 66 * 66) return {KEY, 0, abs(dx) > abs(dy) ? (dx < 0 ? "left" : "right") : (dy < 0 ? "up" : "down")};
  int row = y < 88 ? 0 : y < 136 ? 1 : y < 184 ? 2 : 3;
  if (x < 80) return {KEY, 0, LEFT_KEYS[row]};
  if (x >= 240) return {KEY, 0, RIGHT_KEYS[row]};
  return {NONE, 0, nullptr};
}

// paired[i]: device i is ready (TV always is). lit: the key pressed in the last 200 ms ("" for none).
template <typename T>
void draw(T &it, esphome::font::Font *font, int sel, const bool paired[N], bool pairing, const std::string &code,
          const std::string &lit, const std::string &msg) {
  const Color bg(10, 11, 13), tile(18, 19, 23), line(55, 58, 66), txt(140, 146, 156), green(90, 200, 120),
      dim(60, 64, 72), white(235, 235, 235), sel_bg(30, 46, 36);
  it.fill(bg);
  for (int i = 0; i < N; i++) {
    int x0 = i * 80 + 3; bool s = i == sel;
    it.filled_rectangle(x0, 3, 74, 28, s ? sel_bg : tile);
    it.rectangle(x0, 3, 74, 28, s ? green : line);
    if (s) it.rectangle(x0 + 1, 4, 72, 26, green);
    it.print(x0 + 37, 17, font, paired[i] ? (s ? green : white) : dim, esphome::display::TextAlign::CENTER, DEVS[i].name);
  }
  if (!paired[sel] || pairing) {
    if (!pairing) {
      it.filled_rectangle(50, 90, 220, 60, tile); it.rectangle(50, 90, 220, 60, green); it.rectangle(51, 91, 218, 58, green);
      it.print(160, 110, font, green, esphome::display::TextAlign::CENTER, "Emparejar");
      it.print(160, 132, font, txt, esphome::display::TextAlign::CENTER, DEVS[sel].name);
    } else {
      std::string shown = code; while (shown.size() < 6) shown += '_';
      std::string spaced; for (char ch : shown) { spaced += ch; spaced += ' '; }
      it.print(160, 56, font, white, esphome::display::TextAlign::CENTER, spaced.c_str());
      static const char *keys[12] = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "Borrar", "0", "Cancelar"};
      for (int k = 0; k < 12; k++) {
        int x0 = 40 + (k % 3) * 80 + 2, y0 = 76 + (k / 3) * 40 + 2;
        it.filled_rectangle(x0, y0, 76, 36, tile); it.rectangle(x0, y0, 76, 36, line);
        it.print(x0 + 38, y0 + 18, font, white, esphome::display::TextAlign::CENTER, keys[k]);
      }
    }
  } else {
    auto on = [&](const char *k) { return lit == k; };
    it.filled_circle(160, 140, 66, tile); it.circle(160, 140, 66, line); it.circle(160, 140, 22, line);
    it.filled_circle(160, 140, 21, on("center") ? green : Color(32, 34, 40));
    it.print(160, 140, font, white, esphome::display::TextAlign::CENTER, "OK");
    it.filled_triangle(160, 84, 150, 98, 170, 98, on("up") ? green : white);
    it.filled_triangle(160, 196, 150, 182, 170, 182, on("down") ? green : white);
    it.filled_triangle(104, 140, 118, 130, 118, 150, on("left") ? green : white);
    it.filled_triangle(216, 140, 202, 130, 202, 150, on("right") ? green : white);
    for (int i = 0; i < 4; i++) {
      int y0 = 42 + i * 48;
      it.filled_rectangle(4, y0, 72, 42, on(LEFT_KEYS[i]) ? sel_bg : tile); it.rectangle(4, y0, 72, 42, on(LEFT_KEYS[i]) ? green : line);
      it.print(40, y0 + 21, font, white, esphome::display::TextAlign::CENTER, LEFT_LBL[i]);
      it.filled_rectangle(244, y0, 72, 42, on(RIGHT_KEYS[i]) ? sel_bg : tile); it.rectangle(244, y0, 72, 42, on(RIGHT_KEYS[i]) ? green : line);
      it.print(280, y0 + 21, font, white, esphome::display::TextAlign::CENTER, RIGHT_LBL[i]);
    }
  }
  if (!msg.empty()) {
    it.filled_rectangle(20, 214, 280, 22, Color(20, 22, 26));
    it.print(160, 225, font, Color(255, 200, 90), esphome::display::TextAlign::CENTER, msg.c_str());
  }
}

// the HA Google TV remote command for a Joint Remote key name
inline const char *tv_command(const char *k) {
  static const char *names[][2] = {{"center", "DPAD_CENTER"}, {"left", "DPAD_LEFT"}, {"right", "DPAD_RIGHT"}, {"up", "DPAD_UP"},
      {"down", "DPAD_DOWN"}, {"back", "BACK"}, {"home", "HOME"}, {"mute", "MUTE"}, {"previous", "MEDIA_PREVIOUS"},
      {"volume_up", "VOLUME_UP"}, {"volume_down", "VOLUME_DOWN"}, {"play_pause", "MEDIA_PLAY_PAUSE"}, {"next", "MEDIA_NEXT"}};
  for (auto &n : names) if (!strcmp(n[0], k)) return n[1];
  return nullptr;
}
}  // namespace jr
