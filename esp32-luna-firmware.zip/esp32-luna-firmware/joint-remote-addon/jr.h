#pragma once
// Joint Remote client for the BOX (Mau 27/11): the BOX pairs with each device's Joint Remote receiver like a phone
// does (6-digit code shown on the device), then sends signed key presses. Protocol (Receiver.kt / Auth.kt):
//   POST /pair/start                       -> the device shows a 6-digit code
//   POST /pair/finish {id,name,kind,code}  -> {id,name,kind,secret}
//   POST /cmd {type:key,key}  headers X-Id, X-Time (ms), X-Nonce, X-Sig = b64(HMAC-SHA256(secret, "POST\n/cmd\n"+time+"\n"+nonce+"\n"+body))
#include "esphome.h"
#include "esphome/components/http_request/http_request.h"
#include "mbedtls/md.h"
#include "mbedtls/base64.h"
#include "esp_random.h"
#include <string>
#include <vector>

namespace jr {
using esphome::http_request::Header;
using esphome::http_request::HttpRequestComponent;

struct Dev { const char *name; const char *host; bool ha_tv; };
// TV keys go through HA's Google TV remote (the same protocol Joint Remote itself uses for the TV)
static const Dev DEVS[4] = {{"TV", "192.168.0.179", true}, {"Tablet", "192.168.0.167", false},
                            {"F5 Pro", "192.168.0.168", false}, {"OnePlus", "192.168.0.117", false}};
static const int N = 4;
static const char *MY_ID = "esp32-luna-box";
static const char *MY_NAME = "ESP32 Luna";

inline std::string b64(const uint8_t *d, size_t n) {
  unsigned char buf[128]; size_t o = 0;
  mbedtls_base64_encode(buf, sizeof buf, &o, d, n);
  return std::string((const char *) buf, o);
}
inline std::vector<uint8_t> unb64(const std::string &s) {
  unsigned char buf[96]; size_t o = 0;
  if (mbedtls_base64_decode(buf, sizeof buf, &o, (const unsigned char *) s.data(), s.size()) != 0) return {};
  return std::vector<uint8_t>(buf, buf + o);
}
inline std::string sign(const std::string &secret_b64, const std::string &msg) {
  auto k = unb64(secret_b64); uint8_t out[32];
  mbedtls_md_hmac(mbedtls_md_info_from_type(MBEDTLS_MD_SHA256), k.data(), k.size(),
                  (const unsigned char *) msg.data(), msg.size(), out);
  return b64(out, 32);
}
inline std::string nonce() {
  char b[17]; snprintf(b, sizeof b, "%08lx%08lx", (unsigned long) esp_random(), (unsigned long) esp_random());
  return b;
}
// POST, read the whole reply; returns the HTTP status (-1 = no connection)
inline int post(HttpRequestComponent *h, const std::string &url, const std::string &body,
                const std::vector<Header> &hdr, std::string &resp) {
  resp.clear();
  auto c = h->post(url, body, hdr);
  if (!c) return -1;
  int st = c->status_code;
  uint8_t buf[256];
  for (int i = 0; i < 40; i++) {
    int n = c->read(buf, sizeof buf);
    if (n <= 0) break;
    resp.append((const char *) buf, n);
    if (c->content_length && resp.size() >= c->content_length) break;
  }
  c->end();
  return st;
}
// tiny JSON string field reader ({"secret":"..."})
inline std::string field(const std::string &js, const char *key) {
  std::string k = std::string("\"") + key + "\"";
  size_t p = js.find(k); if (p == std::string::npos) return "";
  p = js.find(':', p); if (p == std::string::npos) return "";
  p = js.find('"', p); if (p == std::string::npos) return "";
  size_t e = js.find('"', p + 1); if (e == std::string::npos) return "";
  return js.substr(p + 1, e - p - 1);
}
inline std::string url(int d, const char *path) { return std::string("http://") + DEVS[d].host + ":8733" + path; }

inline int pair_start(HttpRequestComponent *h, int d) {
  std::string r; return post(h, url(d, "/pair/start"), "{}", {{"Content-Type", "application/json"}}, r);
}
// returns the secret ("" on failure) and the device's error text in err
inline std::string pair_finish(HttpRequestComponent *h, int d, const std::string &code, std::string &err) {
  std::string body = std::string("{\"id\":\"") + MY_ID + "\",\"name\":\"" + MY_NAME + "\",\"kind\":\"box\",\"code\":\"" + code + "\"}";
  std::string r; int st = post(h, url(d, "/pair/finish"), body, {{"Content-Type", "application/json"}}, r);
  if (st != 200) { err = st < 0 ? "sin conexión" : field(r, "error"); if (err.empty()) err = "error " + std::to_string(st); return ""; }
  return field(r, "secret");
}
// one signed key press; time_ms from HA's clock
inline int key(HttpRequestComponent *h, int d, const std::string &secret_b64, const char *k, int64_t time_ms) {
  std::string body = std::string("{\"type\":\"key\",\"key\":\"") + k + "\"}";
  std::string n = nonce(), t = std::to_string((long long) time_ms);
  std::string sig = sign(secret_b64, "POST\n/cmd\n" + t + "\n" + n + "\n" + body);
  std::string r;
  return post(h, url(d, "/cmd"), body, {{"Content-Type", "application/json"}, {"X-Id", MY_ID}, {"X-Time", t},
                                         {"X-Nonce", n}, {"X-Sig", sig}}, r);
}
}  // namespace jr
