# Joint Remote add-on for the BOX firmware

Turns a page of the BOX into a Joint Remote controller:
- **Device buttons** along the top: TV · Tablet · F5 Pro · OnePlus.
- **The remote** below: D-pad + OK, Atrás · Inicio · Mute · Anterior on the left, Vol + · Vol − · Play · Siguiente on the right.

The phones and tablet are paired like any Joint Remote device:
1. The BOX asks for pairing, and the device shows a 6-digit code.
2. You type the code on the BOX keypad.
3. Every key press after that is signed with the shared secret, exactly like the app does it.

The TV's keys go through HA's Google TV remote (`remote.mautv`), the same protocol Joint Remote uses for the TV.

## Files
- `jr.h`: the protocol: pairing, HMAC-SHA256 signing and the HTTP calls to `:8733`.
- `jr_ui.h`: the page layout. `jr::draw()` paints it and `jr::hit()` maps a tap to an action. Both use the same coordinates.
- `joint_remote.yaml`: ESPHome package:
  - `http_request`, an HA time source and a 16 px font;
  - the globals (the pairing secrets are kept across reboots and OTA updates);
  - the `jr_tap` and `jr_tv_key` scripts.

Change the device list (names and IPs) in `jr.h`, `DEVS[]`.

## Add it to your firmware (3 edits)
1. Include the package at the top level of your YAML:
   ```yaml
   packages:
     joint_remote: !include joint-remote-addon/joint_remote.yaml
   ```
2. In the display page that shows the remote, draw it:
   ```cpp
   bool paired[4]; for (int i = 0; i < 4; i++) paired[i] = jr::DEVS[i].ha_tv || id(jr_secret)[i][0] != 0;
   uint32_t n = millis();
   jr::draw(it, id(jr_font), id(jr_sel), paired, id(jr_pairing), id(jr_code),
            n - id(jr_press_at) < 200 ? id(jr_press_key) : std::string(),
            n < id(jr_msg_until) ? id(jr_msg) : std::string());
   ```
3. In your touchscreen handler, when that page is shown, pass each tap (taken when the finger lifts):
   ```cpp
   id(jr_tap).execute(x, y);
   ```

Needs:
- in HA, the ESPHome option "Allow the device to perform Home Assistant actions" (for the TV keys);
- the page redrawing at least ~5 times a second, so the press flash and messages show.

## Pairing a phone or tablet
1. Unlock the device. Its Joint Remote receiver (accessibility service) must be on.
2. On the BOX, tap the device, then «Emparejar»; the device shows a 6-digit code.
3. Type it on the BOX keypad. The BOX keeps the pairing.
- If the device later answers "not paired", the BOX clears it and asks you to pair again.
- Locked or unreachable devices show «Sin respuesta: desbloquea el dispositivo».
