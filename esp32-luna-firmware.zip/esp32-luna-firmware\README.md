# ESP32 (Luna) firmware: ESP32-S3-BOX-3B + BOX-3-DOCK

Built with ESPHome 2026.11.0 (ESP-IDF 5.5.6). The config is `luna_box.yaml`.

## What it does
- **Faces:** animated eyes on a black-wood background, plus the button pages. Swipe left or right to change page; a swipe never presses a button.
- **Voice:** wake words «Luna» (slot 1, Spanish pipeline) and «Hey Luna v3» (slot 2, English pipeline).
- **Joint Remote:** a remote page that drives the TV through HA, plus Android devices running the Joint Remote receiver on port 8733 (paired with HMAC-SHA256). See `joint-remote-addon/README.md`.
- **SD / USB drive modes:** plays GIF, JPG and PNG files from a drive in the dock's USB-A port.

## SD / USB drive
- **Port:** the dock's USB-A port. Use an SD card in a USB reader, or a USB stick. Power the BOX from the dock's back USB-C port; the BOX's own USB-C port is only for a flashing cable.
- **Format:** FAT32. exFAT and NTFS are not supported. Long file names work.
- **Plugging and unplugging:** both are safe while the BOX is running. The selected mode starts again when a drive is plugged in.
- **Folders:** one per mode, at the top level of the drive. Names are matched ignoring capitals and a final «s», so `Logo` or `logos` both work:

      Slideshow/  GIF/  Pop/  Logos/  Memes/  Others/

- **Files:** `.gif`, `.jpg`, `.jpeg` and `.png`.
  - GIFs must be GIF89a with a global colour table; 320×240 fills the screen.
  - Pictures keep their shape and are centred on black.
  - Big JPGs are scaled down while decoding (1/2, 1/4 or 1/8).
- **Samples:** `sd-card-samples/` has one example file per folder.

### Home Assistant entities (device «ESP32 (Luna)»)
| Entity | What it does |
|---|---|
| Animation Style (select) | Faces / Slideshow / GIF / Pop / Logos / Memes / Others |
| Archivo actual | the file on screen |
| Archivo siguiente / Archivo anterior | step through the folder |
| Fijar archivo | keep the current file instead of changing every N seconds |
| Archivo fijo (text) | type a file name, extension included, to fix that file |
| Cambiar archivo cada | seconds between files when nothing is fixed (5–600) |
| Releer tarjeta | read the folder again after copying new files |

HA must allow the device to perform Home Assistant actions (ESPHome integration option) for the button tiles.

## Flash over Wi-Fi (BOX already running this firmware)
    esphome run luna_box.yaml --device <BOX IP>
or upload `firmware.ota.bin` from the ESPHome dashboard.
- Wait at least 60 s after an update before pressing Reset or unplugging. Otherwise the bootloader rolls back to the previous firmware.
- If the microphone, speaker or touch report «Failed to initialize» / «Calibration error» after an update, unplug the power for 5 s. Reset alone doesn't fix it.

## Flash over USB (fresh or recovery)
Use a data USB-C cable on the BOX's own port. Hold BOOT, tap RESET, release BOOT, then:

    esptool.py --chip esp32s3 write_flash 0x0 firmware.factory.bin

or use https://web.esphome.io → Connect → Install → `firmware.factory.bin`.

## Build notes
- `components/gif_player`: USB host + mass-storage mount at `/sd`, the GIF decoder (gifdec, reading each file from a copy in PSRAM) and JPG/PNG through ESPHome's `runtime_image`.
- The sdkconfig options in `luna_box.yaml` that matter for the drive:
  - `CONFIG_VFS_SUPPORT_DIR`: ESPHome turns it off, which stops folders from being listed.
  - `CONFIG_FATFS_LFN_HEAP`: long file names.
- `media_list.h`: maps each mode to its folder and lists the files.
- Wood background and GIF frames are big-endian RGB565 (the screen's own byte order), so they're copied straight to the screen.
- Touch: GT911, polled every 20 ms, started after the display (`setup_priority: -100`).
